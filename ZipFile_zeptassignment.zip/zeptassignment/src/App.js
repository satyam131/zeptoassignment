import './App.css';
import ChipInput from './Components/ChipInput';

function App() {
  return (
    <div className="App">
      < ChipInput />
    </div>
  );
}

export default App;
